/**
 * MISI DETEKTIF 2.0 — CODE.GS
 * Backend untuk game GitHub Pages:
 * - POST form: simpan jawapan dan audio ke Google Sheets/Drive
 * - GET JSONP: Penilaian Guru dan Respons Guru
 *
 * Tukar PIN_GURU sebelum digunakan.
 */
const PIN_GURU = '1234';
const NAMA_SHEET = 'Respons Murid';
const NAMA_SPREADSHEET = 'Misi Detektif - Respons Murid';
const NAMA_FOLDER_AUDIO = 'Misi Detektif - Rakaman Suara';

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.action) {
    let result;
    try {
      if (p.action === 'teacherListSubmissions') result = teacherListSubmissions(p.pin);
      else if (p.action === 'teacherSaveAssessment') result = teacherSaveAssessment(p.pin, p.sessionId, p.score, p.feedback);
      else if (p.action === 'getStudentFeedback') result = getStudentFeedback(p.sessionId, p.name, p.klass);
      else result = {ok:false, message:'Tindakan tidak dikenali.'};
    } catch (err) {
      result = {ok:false, found:false, message:String(err && err.message || err)};
    }
    const callback = String(p.callback || '').replace(/[^\w.$]/g, '');
    const json = JSON.stringify(result);
    if (callback) {
      return ContentService.createTextOutput(callback + '(' + json + ');')
        .setMimeType(ContentService.MimeType.JAVASCRIPT);
    }
    return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
  }
  // Jika dibuka terus sebagai Web App, paparkan HTML yang ada dalam projek.
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Misi Detektif: Jejak Kelestarian Alam')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function doPost(e) {
  let result;
  try {
    const raw = e && e.parameter && e.parameter.payload;
    if (!raw) throw new Error('Data penghantaran kosong.');
    const payload = JSON.parse(raw);
    result = submitStudentReport(payload);
  } catch (err) {
    result = {ok:false, message:String(err && err.message || err)};
  }
  // Maklumkan halaman GitHub melalui iframe tersembunyi; tiada data sensitif dihantar semula.
  const safe = JSON.stringify(result).replace(/</g, '\\u003c');
  return HtmlService.createHtmlOutput(
    '<!doctype html><html><head><meta charset="utf-8"></head><body><script>' +
    'try{parent.postMessage({type:"md-submit-result",ok:' + (result && result.ok ? 'true' : 'false') +
    ',message:' + JSON.stringify(String(result && result.message || '')) + ',sessionId:' +
    JSON.stringify(String(result && result.sessionId || '')) + '}, "*");}catch(e){}' +
    '</script>Penghantaran diproses.</body></html>'
  ).setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function setupMisiDetektif() {
  const props = PropertiesService.getScriptProperties();
  let spreadsheetId = props.getProperty('MD_SPREADSHEET_ID');
  let spreadsheet;
  if (spreadsheetId) spreadsheet = SpreadsheetApp.openById(spreadsheetId);
  else {
    spreadsheet = SpreadsheetApp.create(NAMA_SPREADSHEET);
    spreadsheetId = spreadsheet.getId();
    props.setProperty('MD_SPREADSHEET_ID', spreadsheetId);
  }
  let sheet = spreadsheet.getSheetByName(NAMA_SHEET);
  if (!sheet) sheet = spreadsheet.insertSheet(NAMA_SHEET);
  const headers = ['ID Sesi','Tarikh Hantar','Nama Murid','Kelas','Markah Permainan','Jawapan 1','Jawapan 2','Jawapan 3','Pautan Rakaman Suara','Status Penilaian','Markah Guru','Respons Guru','Avatar','Misi Selesai','Tarikh Penilaian'];
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1,1,1,headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,headers.length).setFontWeight('bold');
    sheet.autoResizeColumns(1,headers.length);
  }
  let folderId = props.getProperty('MD_AUDIO_FOLDER_ID');
  let folder;
  if (folderId) folder = DriveApp.getFolderById(folderId);
  else {
    folder = DriveApp.createFolder(NAMA_FOLDER_AUDIO);
    props.setProperty('MD_AUDIO_FOLDER_ID', folder.getId());
  }
  Logger.log('SETUP BERJAYA');
  Logger.log('Google Sheet (Respons Murid): ' + spreadsheet.getUrl());
  Logger.log('Folder rakaman suara: ' + folder.getUrl());
  Logger.log('PIN guru: ' + PIN_GURU);
  return 'Setup berjaya. Buka Execution log untuk pautan Google Sheet.';
}

function dapatkanSheet_() {
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty('MD_SPREADSHEET_ID')) setupMisiDetektif();
  const spreadsheet = SpreadsheetApp.openById(props.getProperty('MD_SPREADSHEET_ID'));
  let sheet = spreadsheet.getSheetByName(NAMA_SHEET);
  if (!sheet) sheet = spreadsheet.insertSheet(NAMA_SHEET);
  if (sheet.getLastRow() === 0) {
    const headers = ['ID Sesi','Tarikh Hantar','Nama Murid','Kelas','Markah Permainan','Jawapan 1','Jawapan 2','Jawapan 3','Pautan Rakaman Suara','Status Penilaian','Markah Guru','Respons Guru','Avatar','Misi Selesai','Tarikh Penilaian'];
    sheet.appendRow(headers);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function folderAudio_() {
  const props = PropertiesService.getScriptProperties();
  let folderId = props.getProperty('MD_AUDIO_FOLDER_ID');
  if (!folderId) {
    setupMisiDetektif();
    folderId = props.getProperty('MD_AUDIO_FOLDER_ID');
  }
  return DriveApp.getFolderById(folderId);
}

function submitStudentReport(payload) {
  if (!payload) throw new Error('Data murid kosong.');
  const sessionId = String(payload.sessionId || '').trim();
  const name = String(payload.name || '').trim();
  const klass = String(payload.klass || '').trim();
  if (!sessionId || !name || !klass) throw new Error('ID sesi, nama murid dan kelas mesti diisi.');

  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const sheet = dapatkanSheet_();
    let audioUrl = '';
    if (payload.audioData) {
      const audioBytes = Utilities.base64Decode(String(payload.audioData));
      if (audioBytes.length > 12 * 1024 * 1024) throw new Error('Rakaman terlalu besar. Cuba rakam lebih pendek.');
      const mime = String(payload.audioMime || 'audio/webm');
      const ext = mime.indexOf('mp4') >= 0 ? 'm4a' : (mime.indexOf('ogg') >= 0 ? 'ogg' : 'webm');
      const file = folderAudio_().createFile(Utilities.newBlob(audioBytes, mime, sessionId + '.' + ext));
      audioUrl = file.getUrl();
    }
    const row = [
      sessionId, new Date(), name, klass, Number(payload.score)||0,
      String(payload.answer1||''), String(payload.answer2||''), String(payload.answer3||''),
      audioUrl, 'Menunggu penilaian', '', '', String(payload.avatar||''),
      JSON.stringify(payload.completedMissions||[]), ''
    ];
    const existing = cariBarisSesi_(sheet, sessionId);
    if (existing) sheet.getRange(existing,1,1,row.length).setValues([row]);
    else sheet.appendRow(row);
    return {ok:true, message:'Jawapan berjaya disimpan dalam Respons Murid.', sessionId:sessionId};
  } finally {
    lock.releaseLock();
  }
}

function cariBarisSesi_(sheet, sessionId) {
  const last = sheet.getLastRow();
  if (last < 2) return 0;
  const ids = sheet.getRange(2,1,last-1,1).getDisplayValues();
  for (let i=0;i<ids.length;i++) if (ids[i][0] === String(sessionId)) return i+2;
  return 0;
}

function sahkanPinGuru_(pin) {
  if (String(pin||'') !== PIN_GURU || PIN_GURU === 'TUKAR_PIN_GURU') throw new Error('PIN guru tidak sah.');
}

function teacherListSubmissions(pin) {
  sahkanPinGuru_(pin);
  const sheet = dapatkanSheet_();
  const last = sheet.getLastRow();
  if (last < 2) return {ok:true,items:[]};
  const values = sheet.getRange(2,1,last-1,15).getValues();
  return {ok:true,items:values.filter(r=>r[0]).map(r=>({
    sessionId:String(r[0]), submittedAt:r[1]?new Date(r[1]).toLocaleString():'',
    name:String(r[2]||''),klass:String(r[3]||''),autoScore:r[4],
    answer1:String(r[5]||''),answer2:String(r[6]||''),answer3:String(r[7]||''),
    audioUrl:String(r[8]||''),status:String(r[9]||'Menunggu penilaian'),
    teacherScore:r[10]===''?'':r[10],teacherFeedback:String(r[11]||'')
  })).reverse()};
}

function teacherSaveAssessment(pin, sessionId, score, feedback) {
  sahkanPinGuru_(pin);
  const sheet = dapatkanSheet_();
  const row = cariBarisSesi_(sheet, String(sessionId||''));
  if (!row) throw new Error('Rekod murid tidak dijumpai.');
  let mark = '';
  if (score !== '' && score != null) {
    mark = Number(score);
    if (!Number.isFinite(mark)||mark<0||mark>100) throw new Error('Markah mesti antara 0 hingga 100.');
  }
  sheet.getRange(row,10).setValue('Telah dinilai');
  sheet.getRange(row,11).setValue(mark);
  sheet.getRange(row,12).setValue(String(feedback||''));
  sheet.getRange(row,15).setValue(new Date());
  return {ok:true,message:'Penilaian dan respons guru telah disimpan.'};
}

function getStudentFeedback(sessionId, name, klass) {
  const sheet = dapatkanSheet_();
  const rowNo = cariBarisSesi_(sheet, String(sessionId||''));
  if (!rowNo) return {found:false};
  const row = sheet.getRange(rowNo,1,1,15).getValues()[0];
  if (String(row[2])!==String(name)||String(row[3])!==String(klass)||String(row[9])!=='Telah dinilai') return {found:false};
  return {found:true,name:String(row[2]),klass:String(row[3]),teacherScore:row[10],teacherFeedback:String(row[11]||'')};
}
